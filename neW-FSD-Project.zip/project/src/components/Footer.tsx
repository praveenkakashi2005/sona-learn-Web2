import React from 'react';
import { GraduationCap, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-navy-900/80 backdrop-blur-lg border-t border-navy-700 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2">
              <GraduationCap className="h-8 w-8 text-blue-400" />
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                Sona-learn
              </span>
            </div>
            <p className="mt-4 text-gray-400">
              Empowering students with cutting-edge online learning experiences.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Contact Info</h3>
            <div className="space-y-3">
              <p className="flex items-center text-gray-400">
                <MapPin className="h-5 w-5 mr-2 text-blue-400" />
                Sona College of Technology
              </p>
              <p className="flex items-center text-gray-400">
                <Mail className="h-5 w-5 mr-2 text-blue-400" />
                soantech.ac.in
              </p>
              <p className="flex items-center text-gray-400">
                <Phone className="h-5 w-5 mr-2 text-blue-400" />
                6381650926
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="/about" className="hover:text-blue-400 transition-colors">About Us</a></li>
              <li><a href="/courses" className="hover:text-blue-400 transition-colors">Courses</a></li>
              <li><a href="/contact" className="hover:text-blue-400 transition-colors">Contact</a></li>
              <li><a href="/privacy" className="hover:text-blue-400 transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-navy-700">
          <p className="text-center text-gray-400">
            © {new Date().getFullYear()} Sona-learn. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;