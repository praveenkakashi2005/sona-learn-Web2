import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const Courses = () => {
  const courses = [
    {
      id: 1,
      title: "Machine Learning Fundamentals",
      instructor: "Dr. Sarah Chen",
      description: "Learn the basics of machine learning algorithms and their applications.",
      image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&q=80&w=400",
      duration: "12 weeks",
      level: "Intermediate"
    },
    {
      id: 2,
      title: "Full Stack Social Media App",
      instructor: "Prof. Alex Turner",
      description: "Build a complete social media platform using React, Node.js, and MongoDB.",
      image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=400",
      duration: "16 weeks",
      level: "Advanced"
    },
    {
      id: 3,
      title: "AI-Powered Chat Application",
      instructor: "Dr. Maya Patel",
      description: "Create a real-time chat app with AI-powered features using OpenAI's GPT.",
      image: "https://images.unsplash.com/photo-1676299081847-c1c78c2e8f39?auto=format&fit=crop&q=80&w=400",
      duration: "10 weeks",
      level: "Advanced"
    },
    {
      id: 4,
      title: "E-Commerce Platform Development",
      instructor: "Prof. David Martinez",
      description: "Build a full-featured e-commerce platform with payment integration.",
      image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop&q=80&w=400",
      duration: "14 weeks",
      level: "Intermediate"
    },
    {
      id: 5,
      title: "Computer Vision Object Detection",
      instructor: "Dr. Lisa Wang",
      description: "Implement real-time object detection using TensorFlow and OpenCV.",
      image: "https://images.unsplash.com/photo-1507146426996-ef05306b995a?auto=format&fit=crop&q=80&w=400",
      duration: "8 weeks",
      level: "Advanced"
    },
    {
      id: 6,
      title: "Recommendation System Design",
      instructor: "Prof. James Wilson",
      description: "Build personalized recommendation engines using collaborative filtering.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=400",
      duration: "10 weeks",
      level: "Intermediate"
    },
    {
      id: 7,
      title: "Real-time Analytics Dashboard",
      instructor: "Dr. Sarah Miller",
      description: "Create a real-time analytics platform with data visualization.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=400",
      duration: "12 weeks",
      level: "Intermediate"
    },
    {
      id: 8,
      title: "Natural Language Processing",
      instructor: "Dr. Emily Zhang",
      description: "Build applications that understand and process human language.",
      image: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=400",
      duration: "10 weeks",
      level: "Advanced"
    },
    {
      id: 9,
      title: "Cloud-Native Development",
      instructor: "Prof. Michael Brown",
      description: "Learn to build and deploy scalable applications on cloud platforms.",
      image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=400",
      duration: "14 weeks",
      level: "Advanced"
    }
  ];

  return (
    <div className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
          Available Courses
        </h1>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Explore our comprehensive collection of courses designed to help you master
          the latest technologies and advance your career.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {courses.map((course) => (
          <div
            key={course.id}
            className="bg-navy-800/50 backdrop-blur-lg rounded-lg overflow-hidden hover:transform hover:scale-105 transition-all duration-300"
          >
            <img
              src={course.image}
              alt={course.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-semibold">{course.title}</h3>
                <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm">
                  {course.level}
                </span>
              </div>
              <p className="text-gray-400 text-sm mb-2">{course.instructor}</p>
              <p className="text-gray-300 mb-4">{course.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">{course.duration}</span>
                <Link
                  to={`/course/${course.id}`}
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors"
                >
                  View Details
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Courses;