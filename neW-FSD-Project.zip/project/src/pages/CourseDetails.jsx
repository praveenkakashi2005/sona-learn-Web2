import React from 'react';
import { useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const CourseDetails = () => {
  const { id } = useParams();

  // Mock course data
  const course = {
    id: parseInt(id),
    title: "Machine Learning Fundamentals",
    instructor: "Dr. Sarah Chen",
    description: "Learn the basics of machine learning algorithms and their applications in real-world scenarios. This comprehensive course covers everything from data preprocessing to model deployment.",
    image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&q=80&w=400",
    duration: "12 weeks",
    level: "Intermediate",
    syllabus: [
      {
        week: 1,
        title: "Introduction to Machine Learning",
        topics: ["What is Machine Learning?", "Types of ML", "Applications"]
      },
      {
        week: 2,
        title: "Data Preprocessing",
        topics: ["Data Cleaning", "Feature Engineering", "Normalization"]
      },
      {
        week: 3,
        title: "Supervised Learning",
        topics: ["Linear Regression", "Classification", "Decision Trees"]
      }
    ]
  };

  return (
    <div className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <Link to="/courses" className="inline-flex items-center text-blue-400 hover:text-blue-300 mb-8">
        <ArrowLeft className="h-5 w-5 mr-2" />
        Back to Courses
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <img
            src={course.image}
            alt={course.title}
            className="w-full h-64 object-cover rounded-lg mb-6"
          />
          <h1 className="text-3xl font-bold mb-4">{course.title}</h1>
          <div className="flex items-center gap-4 mb-6">
            <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full">
              {course.level}
            </span>
            <span className="text-gray-400">{course.duration}</span>
          </div>
          <p className="text-gray-300 mb-8">{course.description}</p>

          <div className="bg-navy-800/50 backdrop-blur-lg rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Course Syllabus</h2>
            <div className="space-y-4">
              {course.syllabus.map((week) => (
                <div key={week.week} className="border-b border-navy-700 pb-4">
                  <h3 className="font-medium mb-2">
                    Week {week.week}: {week.title}
                  </h3>
                  <ul className="list-disc list-inside text-gray-400">
                    {week.topics.map((topic, index) => (
                      <li key={index}>{topic}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-navy-800/50 backdrop-blur-lg rounded-lg p-6 sticky top-24">
            <h2 className="text-xl font-semibold mb-4">Instructor</h2>
            <div className="flex items-center gap-4 mb-6">
              <img
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100"
                alt={course.instructor}
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h3 className="font-medium">{course.instructor}</h3>
                <p className="text-gray-400">Machine Learning Expert</p>
              </div>
            </div>
            <button className="btn-primary w-full">
              Start Learning
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetails;